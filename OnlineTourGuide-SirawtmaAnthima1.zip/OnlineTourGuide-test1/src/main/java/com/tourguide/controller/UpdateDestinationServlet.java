package com.tourguide.controller;

import java.io.IOException;
import java.io.InputStream;



import com.tourguide.bean.DestinationBean;
import com.tourguide.dao.DestinationDao;
import com.tourguide.dao.IDestinationDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

/**
 * Servlet implementation class UpdateDestinationServlet
 */
@WebServlet("/UpdateDestinationServlet")
@MultipartConfig
public class UpdateDestinationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateDestinationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		int destinationID = Integer.parseInt(request.getParameter("destinationID"));
		String destinationName = request.getParameter("destinationName");
		int rating = Integer.parseInt(request.getParameter("rating"));
		String description = request.getParameter("description");
		Part filePart = request.getPart("image");
		
		InputStream inputStream = null;
		
		if(filePart != null) {
			inputStream = filePart.getInputStream();
		}
		
		DestinationBean destinationBean = new DestinationBean();
		
		destinationBean.setDestinationID(destinationID);
		destinationBean.setDestinationName(destinationName);
		destinationBean.setRating(rating);
		destinationBean.setDescription(description);
		destinationBean.setInputStream(inputStream);
		
		IDestinationDao destinaionDao = new DestinationDao();
		
		String updateDestination = destinaionDao.updateDestination(destinationBean);
		
		if(updateDestination.equals("Destination updated successfully!")) {
			request.setAttribute("successMessage", updateDestination);
			request.getRequestDispatcher("/destinations.jsp").forward(request, response);
		} else {
			request.setAttribute("errMessage", updateDestination);
		}
	}

}
